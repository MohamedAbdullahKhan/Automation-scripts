﻿# === Config ===
$backupFolder = "R:\Backup_Files"
$passwordFile = "D:\My Scripts\Robocopy\secure\zip_password.txt"
$extractTo = "D:\Restore"
$sevenZip = "C:\Program Files\7-Zip\7z.exe"

# === Ensure destination folder exists ===
if (-not (Test-Path $extractTo)) {
    New-Item -ItemType Directory -Path $extractTo -Force | Out-Null
}

# === Get latest .7z backup file ===
$latestBackup = Get-ChildItem -Path $backupFolder -Filter "IncrementalBackup_*.7z" | 
    Sort-Object LastWriteTime -Descending | 
    Select-Object -First 1

if (-not $latestBackup) {
    Write-Host "❌ No backup file found in $backupFolder"
    exit 1
}

Write-Host "🗂️ Latest backup found: $($latestBackup.Name)"

# === Load and decrypt password ===
$securePassword = Get-Content $passwordFile | ConvertTo-SecureString
$plainPassword = ([System.Net.NetworkCredential]::new("", $securePassword).Password).Trim()

# === Extract using 7-Zip ===
& $sevenZip x "`"$($latestBackup.FullName)`"" "-p$plainPassword" "-o$extractTo"

Write-Host "`n✅ Extraction complete to $extractTo"
