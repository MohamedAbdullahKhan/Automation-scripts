﻿# Incremental_Backup.ps1

# CONFIG
$source = "D:\My_Files"
$destination = "R:\Backup_Files"
$logDirectory = "D:\My Scripts\Robocopy\Logs"
$passwordFile = "D:\My Scripts\Robocopy\secure\zip_password.txt"
$metaFile = "D:\My Scripts\Robocopy\last_backup_metadata.json"
$sevenZip = "C:\Program Files\7-Zip\7z.exe"

# Timestamp
$timestamp = Get-Date -Format "yyyyMMdd_HHmm"
$stagingDir = Join-Path $env:TEMP "Backup_Staging_$timestamp"
$zipFile = Join-Path $destination "IncrementalBackup_$timestamp.7z"
$zipLog = Join-Path $logDirectory "7z_$timestamp.log"

# Ensure required folders exist
New-Item -ItemType Directory -Force -Path $logDirectory, $stagingDir | Out-Null

# Load password
$securePassword = Get-Content $passwordFile | ConvertTo-SecureString
$plainPassword = ([System.Net.NetworkCredential]::new("", $securePassword).Password).Trim()

# Load previous metadata as hashtable
$previousMeta = @{}
if (Test-Path $metaFile) {
    $rawMeta = Get-Content $metaFile -Raw | ConvertFrom-Json
    $rawMeta.PSObject.Properties | ForEach-Object {
        $previousMeta[$_.Name] = $_.Value
    }
}

# Detect changed or new files
$changedFiles = @()
Get-ChildItem -Path $source -File -Recurse | ForEach-Object {
    $relPath = $_.FullName.Substring($source.Length).TrimStart('\')
    $lastWrite = $_.LastWriteTimeUtc.ToString("o")

    if (-not $previousMeta.ContainsKey($relPath) -or $previousMeta[$relPath] -ne $lastWrite) {
        $changedFiles += $_
    }
}

# Skip if no changes
if ($changedFiles.Count -eq 0) {
    Write-Host "⚠️ No files changed since last backup. Skipping archive creation."
    Remove-Item -Recurse -Force $stagingDir
    exit
}

# Copy changed files to staging
foreach ($file in $changedFiles) {
    $relPath = $file.FullName.Substring($source.Length).TrimStart('\')
    $target = Join-Path $stagingDir $relPath
    $folder = Split-Path $target -Parent
    if (-not (Test-Path $folder)) {
        New-Item -ItemType Directory -Path $folder -Force | Out-Null
    }
    Copy-Item $file.FullName -Destination $target -Force
}

# Compress with 7-Zip
& $sevenZip a -t7z -mhe=on "-p$plainPassword" "$zipFile" "$stagingDir\*" > $zipLog

# Cleanup
Remove-Item -Recurse -Force $stagingDir

# Keep only last 2 backup files
$allBackups = Get-ChildItem $destination -Filter "IncrementalBackup_*.7z" | Sort-Object LastWriteTime -Descending
if ($allBackups.Count -gt 2) {
    $allBackups | Select-Object -Skip 2 | Remove-Item -Force
}

# Save current metadata
$currentMeta = @{}
Get-ChildItem -Path $source -File -Recurse | ForEach-Object {
    $relPath = $_.FullName.Substring($source.Length).TrimStart('\')
    $currentMeta[$relPath] = $_.LastWriteTimeUtc.ToString("o")
}
$currentMeta | ConvertTo-Json | Set-Content -Path $metaFile

Write-Host "`n✅ Backup complete: $zipFile"
