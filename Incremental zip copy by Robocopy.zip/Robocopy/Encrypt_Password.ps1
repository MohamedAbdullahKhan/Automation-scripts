﻿# Save this as Create_EncryptedPassword.ps1 and run it ONCE
$folderPath = "D:\My Scripts\Robocopy\secure"
$passwordFile = "$folderPath\zip_password.txt"
$password = "T3$t@123"  # Your password

if (-not (Test-Path $folderPath)) {
    New-Item -ItemType Directory -Path $folderPath -Force | Out-Null
}

# Convert and save encrypted password
$securePassword = ConvertTo-SecureString -String $password -AsPlainText -Force
$securePassword | ConvertFrom-SecureString | Set-Content -Path $passwordFile

Write-Host "Encrypted password saved to $passwordFile"
